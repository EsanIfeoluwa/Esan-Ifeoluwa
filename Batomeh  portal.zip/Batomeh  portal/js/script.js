	function validate(){
		var search = document.forms["search"]["content"].value;
		if (search == "") {
			alert("you cannot search for an empty string");
		}
		return false;
	}

	function calculateNum(v2, v2) {
		alert(v1 + v2);
	}